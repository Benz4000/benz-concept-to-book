# Execute the workflow in dependency order

Use this route to coordinate a whole book or resume several streams. Start at the actual state and stop at the requested endpoint. The A–L labels in [outcome-stages.md](outcome-stages.md) identify responsibilities; they are not an instruction to finish all I work before starting J or to postpone every cover task until L. Existing accepted work can already satisfy a step.

| Sequence | Work, output and prerequisite |
|---|---|
| 1. Recover and scope | Establish the endpoint, current authoritative sources/outputs, accepted decisions and real gaps. Use CD01 when recovering cover selections. Preserve newer work and valid review evidence. |
| 2. Select profiles | Combine original/adapted, standalone/series and text/illustrated dimensions. Apply only the records and checks needed for the request. |
| 3. Establish the foundation (A) | Recover scoped story/craft/reader/visual/edition/cover choices, examples, priorities and completion criteria. CD02 establishes cover identity and permitted variation; CD03 establishes intended editions. Separate preferences from unknown facts and their blocking milestones. |
| 4. Resolve constraining sources and architecture (B) | Read needed source material with actual provenance, distinguish variants and make bounded adaptation decisions. Plan causal scenes/arcs, story time, character knowledge and reader disclosure. Track material source decisions into their destinations. |
| 5. Calibrate before scaling | If existing evidence does not resolve costly uncertainty, carry representative work through the relevant connected pilot. Test prose depth/voice, layout or art/copy/type/crop together as applicable. CD05 can use working copy, but final fit remains unverified until the actual intended copy/font/surface is tested. |
| 6. Create and develop (C/D) | Draft planned main and companion material; update canon and knowledge as it changes. Consolidate demonstrated structural/agency/consequence gaps and repair them against the intended experience. |
| 7. Polish prose and reader material (E/F) | Improve the established voice and complete canon-dependent recaps, profiles, afterwords, citations and navigation. Apply actual feedback proportionately. Keep source and spoiler boundaries. |
| 8. Read the integrated edition (G) | Review the required full reading scope in its intended order, record exact coverage and repair affected context. Selective scans and declaration checks do not substitute for that scope. |
| 9. Verify edition/tool capability (H) | Confirm intended format, typography, layout, available builders and real destination constraints against actual representative output. Reuse valid earlier pilots. A missing print fact need not block independent digital work. |
| 10. Prepare assets and reading/interior builds (J/I) | CD04 selects source-grounded cover art; CD06 writes distinct copy; CD07 prepares relevant icons/panels; CD08 checks actual type/contrast. These design tasks can begin earlier once their own inputs are stable. Integrate the required interior assets and build the requested reading/interior edition from an exact snapshot. Include a digital front cover when requested. |
| 11. Inspect the interior/readable format (K) | Check actual pages/navigation/reading behavior and relevant accessibility. Repair, rebuild and recheck affected areas. If text/layout changed after a prior review, recover what changed and renew the affected editorial and rendered checks, including downstream pagination/navigation. Establish the current interior's exact file and count evidence; identity/count alone is not review evidence, and manufacturing counts must not be guessed. |
| 12. Assemble physical cover editions (L/CD09) | When physical covers are requested and the relevant actual template/count/trim/paper/binding/identity inputs exist, assemble each wrap/jacket independently. A provisional count produces provisional geometry. Front concepts can proceed earlier; front previews are not completed physical covers. |
| 13. Inspect and repair those covers (K/CD10–CD11) | Inspect actual exported front/back/spine/flap surfaces at relevant scale. Repair fit/contrast/crop or identified technical defects with protected inputs and derivative provenance. Rebuild the affected cover when an upstream input changes. |
| 14. Match and hand off (L/CD12) | Match exact interior-cover versions and evidence for each edition. Preserve prior releases; report the requested local deliverable or authorized external action at its highest evidenced state. Record pending checks and enough state to recover. |
| 15. Learn only from evidence | Record substantial rework causes and scoped lessons. Promote established preferences to the next applicable foundation without treating discoveries or new user direction as preventable failures. |

Use [reference-provenance.md](reference-provenance.md) at every actual source consultation. Likely source needs change across the route: prior decisions/craft guidance in foundation, primary/secondary story sources in architecture, canon during drafting and reader material, appearance references in art, and actual fonts/code/templates/requirements in production. These are triggers to consult relevant material, not a requirement to reread the entire vault at every step. A source already applied can be reused with its previous reading scope disclosed.

## What can proceed in parallel

- Narrative drafting can proceed while final ISBN/spine geometry remains unknown if those facts do not constrain it.
- Cover composition, copy and typography can develop together once their story/identity inputs are sufficiently stable. A late reveal still constrains every early reader-facing surface.
- Interior layout and asset preparation can interleave. Keep each release snapshot consistent; rebuild affected output when its selected asset changes.
- Different editions have separate dependencies. A paperback page-count change does not automatically invalidate an unchanged hardcover interior or its correctly paired review. Verify the relevant input identity before retaining evidence.

## Local revision loop and stopping rule

For each material issue: identify the goal and actual gap → identify authoritative inputs and what must be preserved → repair the smallest sufficient scope → follow changed dependencies → inspect the actual result and required context → retain or revise the repair.

Group compatible issues by outcome and affected scope. Do not merge unrelated edits just because they are nearby, and do not repeat whole-book reviews when unchanged evidence remains valid. A new user direction can justify broader work; record the change rather than calling it routine polish.

Stop when the requested output meets its established criteria, required review coverage is complete, material blocking issues are resolved, and residual limits are explicit. This is a scoped acceptance decision, not a claim of perfection. Do not add another version or pass solely to continue a cycle. If a real blocker needs a missing source or user decision, preserve the candidate and continue independent work; time spent does not convert uncertainty into approval.

## Skill maintenance is a separate cycle

The sixth V6 enhancement—actual file-based integration testing—validates the reusable production/checking tools when they change. It is not an extra test-book build required for each author. Use [skill-evaluation.md](skill-evaluation.md) and [integration-testing.md](integration-testing.md) for consequential skill changes, holding criteria back from blind executors and retaining results outside reusable fixtures. Reuse unchanged helper evidence honestly; rerun only affected behavior and required preservation checks. When an independent audit and appropriate tests find no remaining material gap, deliver the polished version and preserve earlier versions.
